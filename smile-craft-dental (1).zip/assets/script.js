// Smile Craft Dental — shared behavior across all pages

document.addEventListener('DOMContentLoaded', () => {

  // Mobile nav toggle
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('open');
      hamburger.setAttribute('aria-expanded', isOpen);
    });
    navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      navLinks.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    }));
  }

  // Before/After slider (Smile Gallery + Home preview)
  document.querySelectorAll('.slider-frame').forEach(frame => {
    const range = frame.querySelector('.ba-range');
    const handle = frame.querySelector('.handle');
    if (!range) return;
    range.addEventListener('input', () => {
      frame.style.setProperty('--pos', range.value + '%');
      if (handle) handle.style.left = range.value + '%';
    });
  });

  // FAQ / Insurance accordion
  document.querySelectorAll('.accordion-item button').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.parentElement;
      const group = item.closest('.accordion-group') || item.parentElement;
      const body = item.querySelector('.accordion-body');
      const isOpen = item.classList.contains('open');
      group.querySelectorAll('.accordion-item').forEach(i => {
        i.classList.remove('open');
        const b = i.querySelector('.accordion-body');
        if (b) b.style.maxHeight = null;
        i.querySelector('button').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        body.style.maxHeight = body.scrollHeight + 'px';
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });
  // Pre-open any .open accordion items on load
  document.querySelectorAll('.accordion-item.open .accordion-body').forEach(b => {
    b.style.maxHeight = b.scrollHeight + 'px';
  });

  // Form submission — real Netlify Forms AJAX submit (falls back to normal
  // browser POST if the fetch fails, e.g. offline), with inline confirmation.
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', (e) => {
      const confirmId = form.getAttribute('data-confirm');
      const confirmEl = document.getElementById(confirmId);
      const submitBtn = form.querySelector('button[type="submit"]');

      // Only intercept for AJAX when this is a real Netlify form.
      if (form.hasAttribute('data-netlify')) {
        e.preventDefault();
        if (submitBtn) { submitBtn.disabled = true; submitBtn.dataset.label = submitBtn.textContent; submitBtn.textContent = 'Sending...'; }

        const data = new FormData(form);
        fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(data).toString()
        })
          .then(() => {
            form.reset();
            if (confirmEl) {
              confirmEl.classList.add('show');
              setTimeout(() => confirmEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 50);
            }
          })
          .catch(() => {
            // Network hiccup — fall back to a normal browser form POST.
            // (form.submit() does not re-fire the 'submit' event, so this is safe.)
            form.submit();
          })
          .finally(() => {
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = submitBtn.dataset.label; }
          });
      } else {
        // No backend wired up — demo-only inline confirmation.
        e.preventDefault();
        if (confirmEl) {
          confirmEl.classList.add('show');
          setTimeout(() => confirmEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 50);
        }
      }
    });
  });

  // Live chat panel
  const chatBtn = document.getElementById('chatToggle');
  const chatPanel = document.getElementById('chatPanel');
  const chatClose = document.getElementById('chatClose');
  if (chatBtn && chatPanel) {
    chatBtn.addEventListener('click', () => chatPanel.classList.toggle('open'));
    if (chatClose) chatClose.addEventListener('click', () => chatPanel.classList.remove('open'));
  }
  const chatForm = document.getElementById('chatForm');
  if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('chatInput');
      const body = document.getElementById('chatBody');
      if (input.value.trim()) {
        const mine = document.createElement('div');
        mine.className = 'chat-bubble';
        mine.style.alignSelf = 'flex-end';
        mine.style.background = '#EAF6F4';
        mine.textContent = input.value.trim();
        body.appendChild(mine);
        input.value = '';
        setTimeout(() => {
          const reply = document.createElement('div');
          reply.className = 'chat-bubble';
          reply.textContent = "Thanks for reaching out! Our front desk will reply shortly, or call (212) 555-0148 for anything urgent.";
          body.appendChild(reply);
          body.scrollTop = body.scrollHeight;
        }, 500);
        body.scrollTop = body.scrollHeight;
      }
    });
  }

  // Scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }
});
